package ecplugins.workflowDashboard.client;

/**
 * Created by IntelliJ IDEA.
 * User: jthorpe
 * Date: 2/28/12
 * Time: 5:57 PM
 * To change this template use File | Settings | File Templates.
 */
import com.google.gwt.resources.client.CssResource;

public interface DashboardStyles 
extends CssResource{

    String no_underline();
}

