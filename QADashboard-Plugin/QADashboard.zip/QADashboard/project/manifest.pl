@files = (
    ['//property[propertyName="ec_setup"]/value', 'ec_setup.pl'],
);
